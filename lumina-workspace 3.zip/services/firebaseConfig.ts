
// Firebase a été retiré pour utiliser le LocalStorage.
export const isFirebaseConfigured = false;
export const auth = null;
export const db = null;
