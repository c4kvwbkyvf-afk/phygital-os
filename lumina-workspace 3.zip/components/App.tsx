
import React, { useState, useEffect } from 'react';
import Sidebar from './components/Sidebar.tsx';
import Dashboard from './components/Dashboard.tsx';
import Orders from './components/Orders.tsx';
import Stock from './components/Stock.tsx';
import Logistics from './components/Logistics.tsx';
import Settings from './components/Settings.tsx';
import Accounting from './components/Accounting.tsx';
import Finance from './components/Finance.tsx';
import HR from './components/HR.tsx';
import Marketing from './components/Marketing.tsx';
import Auth from './components/Auth.tsx';
import { ViewMode, Language, User, AppNotification } from './types.ts';
import { isRTL } from './services/languageService.ts';
import { getCurrentUser, logout } from './services/authService.ts';
import { requestNotifPermission } from './services/notificationService.ts';

const App: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);
  const [currentView, setCurrentView] = useState<ViewMode>(ViewMode.DASHBOARD);
  const [lang, setLang] = useState<Language>('fr');
  const [darkMode, setDarkMode] = useState(false);
  const [loading, setLoading] = useState(true);
  const [activeToast, setActiveToast] = useState<AppNotification | null>(null);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const session = getCurrentUser();
    if (session) {
        setUser(session);
        requestNotifPermission();
    }
    setLoading(false);

    const handleNotif = (e: any) => {
        setActiveToast(e.detail);
        setTimeout(() => setActiveToast(null), 8000);
    };
    window.addEventListener('app-notification', handleNotif);
    return () => window.removeEventListener('app-notification', handleNotif);
  }, []);

  useEffect(() => {
    if (darkMode) document.body.classList.add('dark');
    else document.body.classList.remove('dark');
  }, [darkMode]);

  const renderView = () => {
    switch (currentView) {
      case ViewMode.DASHBOARD: return <Dashboard onViewChange={setCurrentView} lang={lang} />;
      case ViewMode.ORDERS: return <Orders lang={lang} />;
      case ViewMode.STOCK: return <Stock lang={lang} />;
      case ViewMode.LOGISTICS: return <Logistics lang={lang} />;
      case ViewMode.FINANCE: return <Finance lang={lang} />;
      case ViewMode.ACCOUNTING: return <Accounting lang={lang} />;
      case ViewMode.MARKETING: return <Marketing lang={lang} onViewChange={setCurrentView} />;
      case ViewMode.HR: return <HR lang={lang} />;
      case ViewMode.SETTINGS: return <Settings />;
      default: return <div className="p-12 text-center text-slate-400">Module en développement...</div>;
    }
  };

  if (loading) return <div className="min-h-screen flex items-center justify-center bg-[#F2F2F7]"><div className="w-8 h-8 border-4 border-ios-blue border-t-transparent rounded-full animate-spin"></div></div>;
  if (!user) return <Auth onLoginSuccess={(u) => setUser(u)} />;

  return (
    <div className={`flex h-screen overflow-hidden ${darkMode ? 'dark' : ''}`} dir={isRTL(lang) ? 'rtl' : 'ltr'}>
      <Sidebar 
        currentView={currentView} 
        onViewChange={(v) => { setCurrentView(v); setIsMobileMenuOpen(false); }} 
        lang={lang} setLang={setLang} darkMode={darkMode} setDarkMode={setDarkMode} 
      />
      
      <main className="flex-1 flex flex-col h-full overflow-hidden bg-ios-bg dark:bg-black relative">
        <header className="h-20 apple-card-premium flex justify-between items-center px-10 z-20 flex-shrink-0 mx-6 mt-6 border border-white/40 shadow-xl">
            <div className="flex items-center gap-6">
              <button 
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                className="md:hidden p-3 rounded-2xl bg-black/5 dark:bg-white/5 active:scale-90 transition-transform"
              >
                <svg className="w-6 h-6 text-slate-800 dark:text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M4 6h16M4 12h16M4 18h16" /></svg>
              </button>
              <h2 className="text-[13px] font-black text-slate-800 dark:text-white uppercase tracking-[0.3em] hidden sm:block opacity-40">{currentView}</h2>
              <div className="sm:hidden text-lg font-black text-ios-blue tracking-tighter">Phygital<span className="text-black dark:text-white">OS</span></div>
            </div>
            
            <div className="flex items-center gap-6">
                <div className="hidden lg:block text-right">
                    <div className="text-[12px] font-black dark:text-white leading-none uppercase tracking-wide">{user.companyName}</div>
                    <div className="text-[9px] font-black text-ios-blue uppercase tracking-[0.2em] mt-1.5">Admin Level</div>
                </div>
                <button onClick={logout} className="h-11 w-11 rounded-2xl apple-card-premium border-white/60 flex items-center justify-center font-black text-ios-blue text-xs shadow-lg active:scale-90 transition-all hover:ring-4 ring-ios-blue/10">
                    {user.name.charAt(0)}
                </button>
            </div>
        </header>

        <div className="flex-1 overflow-y-auto p-6 sm:p-10 scroll-smooth no-scrollbar">
          <div className="animate-fade-in pb-12">
            {renderView()}
          </div>
        </div>

        {/* Mobile Menu Overlay - Liquid Style */}
        {isMobileMenuOpen && (
          <div className="fixed inset-0 z-50 md:hidden flex" onClick={() => setIsMobileMenuOpen(false)}>
             <div className="absolute inset-0 bg-black/40 backdrop-blur-md animate-in fade-in duration-500"></div>
             <div className="w-80 h-[calc(100vh-32px)] m-4 bg-transparent relative animate-in slide-in-from-left duration-500" onClick={e => e.stopPropagation()}>
                <Sidebar 
                  currentView={currentView} 
                  onViewChange={(v) => { setCurrentView(v); setIsMobileMenuOpen(false); }} 
                  lang={lang} setLang={setLang} darkMode={darkMode} setDarkMode={setDarkMode} 
                />
             </div>
          </div>
        )}

        {activeToast && (
            <div className={`fixed bottom-10 left-1/2 -translate-x-1/2 w-[90%] md:w-auto md:min-w-[400px] z-[100] animate-in fade-in slide-in-from-bottom-6 duration-500`}>
                <div className={`apple-card-premium p-6 rounded-[32px] border-l-[12px] shadow-2xl flex items-center gap-6 ${
                    activeToast.type === 'error' ? 'border-rose-500' : 'border-amber-500'
                }`}>
                    <div className="flex-1">
                        <h4 className="font-black text-[12px] uppercase tracking-[0.1em] dark:text-white">{activeToast.title}</h4>
                        <p className="text-[11px] font-bold text-slate-500 dark:text-slate-400 mt-2 leading-relaxed opacity-80">{activeToast.message}</p>
                    </div>
                </div>
            </div>
        )}
      </main>
    </div>
  );
};

export default App;
